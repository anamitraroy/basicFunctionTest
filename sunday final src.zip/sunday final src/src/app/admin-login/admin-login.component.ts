import {OnInit} from '@angular/core';
import { Component } from "@angular/core";

@Component({
    selector : 'admin-login',
    templateUrl: './admin-login.component.html',
    
   
})


export class AdminLoginComponent  {

    constructor(){

    }
}