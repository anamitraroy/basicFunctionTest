export class Admin{
    constructor(public email?: string,
                public password?:string,
                public otp?:string)
               {

     }
}
