export class RetailerHomepage{
    constructor(public name?: string,
        public image?:string,
        public description?:string,
        public price?:number,
        )  {}
}
