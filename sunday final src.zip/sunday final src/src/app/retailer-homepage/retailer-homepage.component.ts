import {OnInit} from '@angular/core';
import { Component } from '@angular/core';

@Component({
    selector : 'retailer-homepage',
    templateUrl: './retailer-homepage.component.html',
})


export class RetailerHomepage {
   
}
