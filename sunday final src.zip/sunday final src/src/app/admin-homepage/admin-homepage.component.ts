import {OnInit} from '@angular/core';
import { Component } from "@angular/core";

@Component({
    selector : 'admin-homepage',
    templateUrl:'./admin-homepage.component.html',
})


export class AdminHomepageComponent  {
    
   // elements:Retailer[];
    constructor(){

    }
   
}