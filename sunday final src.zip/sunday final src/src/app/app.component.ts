import { Component } from '@angular/core';
import { LoginComponent } from 'src/Registration/Login-module/login-module.component';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { RetailerLoginComponent } from './retailerLogin/retailer-login.component';
import { RegistrationComponent } from 'src/Registration/registration-form.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ShoppingApp';
}
