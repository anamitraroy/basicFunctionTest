package com.lti.homeloan.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.lti.homeloan.dao.AdminDao;
import com.lti.homeloan.dto.AdminLoginDTO;
import com.lti.homeloan.entity.AdminEntity;
import com.lti.homeloan.entity.ApplicationEntity;
import com.lti.homeloan.entity.LoanEntity;
import com.lti.homeloan.service.AdminService;

public class AdminTest {

	@Test
	public void adminLoginTest() {
		AdminLoginDTO dto = new AdminLoginDTO();
		dto.setUserName("admin");
		dto.setPassword("admin");
		
		ApplicationContext ctx = new FileSystemXmlApplicationContext("src/main/webapp/WEB-INF/spring-config.xml");
		AdminDao dao = ctx.getBean(AdminDao.class);
		
		System.out.println("Username: " + dao.fetchAdmin(dto).getUserName());
		//System.out.println(dao.fetchAdmin(dto).getPassword());
	}
	
	@Test
	public void adminFetchApprovedLoansTest() {
		ApplicationContext ctx = new FileSystemXmlApplicationContext("src/main/webapp/WEB-INF/spring-config.xml");
		AdminDao dao = ctx.getBean(AdminDao.class);
		
		List<LoanEntity> loans = dao.fetchApprovedLoans();
		for (LoanEntity loanEntity : loans) {
			System.out.print(loanEntity.getLoanAmount() + "\t");
			System.out.print(loanEntity.getDuration() + "\t");
		}
	}
	
	@Test
	public void adminFetchApplicationsTest() {
		ApplicationContext ctx = new FileSystemXmlApplicationContext("src/main/webapp/WEB-INF/spring-config.xml");
		AdminDao dao = ctx.getBean(AdminDao.class);
		
		List<ApplicationEntity> applications = dao.fetchApplications();
		for (ApplicationEntity apps : applications) {
			
		}
	}
	
	@Test
	public void adminFetchSingleApplication() {
		ApplicationContext ctx = new FileSystemXmlApplicationContext("src/main/webapp/WEB-INF/spring-config.xml");
		AdminDao dao = ctx.getBean(AdminDao.class);
		
		
	}
	
	@Test
	public void adminVerifyApplication() {
		ApplicationContext ctx = new FileSystemXmlApplicationContext("src/main/webapp/WEB-INF/spring-config.xml");
		AdminDao dao = ctx.getBean(AdminDao.class);
		dao.verifyApplication(100);
	}
}
