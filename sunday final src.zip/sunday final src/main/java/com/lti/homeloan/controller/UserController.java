package com.lti.homeloan.controller;


import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.lti.homeloan.dao.GenericDao;
import com.lti.homeloan.dao.UserDao;
import com.lti.homeloan.dto.FileUploadDTO;
import com.lti.homeloan.dto.LoanApplicationDTO;
import com.lti.homeloan.dto.LoginDTO;
import com.lti.homeloan.dto.UserDTO;
import com.lti.homeloan.dto.UserIncomeDetailsDTO;
import com.lti.homeloan.entity.FileUploadEntity;
import com.lti.homeloan.entity.UserEntity;
import com.lti.homeloan.service.LoginService;
import com.lti.homeloan.service.UserService;

@Controller
@SessionAttributes("user")
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private LoginService loginService;
	
	@Autowired
	private UserDao userDao;

	@RequestMapping(path="/register", method = RequestMethod.POST)
	public String register(UserDTO registerDTO,Map<String, Object> model) {
		userService.register(registerDTO);
		model.put("registrationDetails", registerDTO);
		return "/confirmation.jsp";
	}
	@RequestMapping(path = "/login", method = RequestMethod.POST)
	public String login(LoginDTO loginDTO, Map<String, Object> model, HttpSession session) {
		
		UserEntity e = loginService.login(loginDTO);
		if (e != null) {
			model.put("user", e);
			session.setAttribute("user", e);
			//System.out.println(e.getId());
			return "/userDash.jsp";
		} else {
			return "/fail.jsp";
		}
	}
	
	@RequestMapping(path = "/getQuestion", method = RequestMethod.POST)
	public String initForm(LoginDTO loginDTO, Map<String, Object> model) {

		UserEntity entity = loginService.checkEmail(loginDTO);
		
		if(entity==null) {
			return"/login.jsp";
		}
		else {
		model.put("userDetails", entity);
		return "/securityAnswer.jsp";
	}
	}

	@RequestMapping(path = "/getAnswer", method = RequestMethod.POST)
	public String processAnswer(LoginDTO loginDTO, Map<String, Object> model) {

		boolean isValid = loginService.checkAnswer(loginDTO);
		if (isValid) {
			UserEntity user = (UserEntity) model.get("userDetails");
			System.out.println(user.getEmailId());
			return "/passwordReset.jsp";
		}
			
		else
			model.put("error", "Incorrect Answer...!!");
			return "/securityAnswer.jsp";

	}

	@RequestMapping(path="/updatePassword", method=RequestMethod.POST)
	public String resetPassword(LoginDTO loginDTO) {
		loginService.resetPassword(loginDTO);
		return "redirect:/login.jsp";
	}
	@RequestMapping(path="/logOut",method=RequestMethod.POST)
	public String logOut(HttpSession session) {
		session.invalidate();
		return" 8963";	    //homepage
	}

	@RequestMapping(path="/incomeDetails",method=RequestMethod.POST)
	public String addIncomeDetails(UserIncomeDetailsDTO userIncomeDetailsDTO,Map<String,Object> model, HttpSession session) {
		UserEntity user = (UserEntity) session.getAttribute("user");
		//UserEntity user = (UserEntity) model.get("user");
		/*UserEntity user = userDao.fetch(UserEntity.class, 470);
		System.out.println(user.getId());*/
		System.out.println(userIncomeDetailsDTO.getMonthlyIncome());
		userService.addIncomeDetails(userIncomeDetailsDTO, user);
		model.put("incomeDetails", userIncomeDetailsDTO);
		return "redirect:/loanDetails.jsp";
	}
	
	@RequestMapping(path="/loanDetails",method=RequestMethod.POST)
	public String addLoanApplication(LoanApplicationDTO loanApplicationDTO, HttpSession session) {
		UserEntity user = (UserEntity) session.getAttribute("user");
		userService.addPropertyDetails(loanApplicationDTO, user);
		return"redirect:/documentUpload.jsp";
	}
	
	@RequestMapping(path="/fileUpload" ,method=RequestMethod.POST)
	public String fileUpload(FileUploadDTO fileUploadDTO, Map<String, Object> model, HttpSession session) {
		
		System.out.println(session.getAttribute("user"));
		UserEntity user = (UserEntity) session.getAttribute("user");
		int userId = user.getId();
		//System.out.println(user.getId());
		
		//TODO : rename the file since two users can upload file of same name
		File targetDir1 = new File("d:/uploads/" + userId + "-" + fileUploadDTO.getAadharCard().getOriginalFilename()); 
		File targetDir2 = new File("d:/uploads/" + userId + "-" + fileUploadDTO.getVoterId().getOriginalFilename()); 
		File targetDir3 = new File("d:/uploads/" + userId + "-" + fileUploadDTO.getSalarySlip().getOriginalFilename()); 
		File targetDir4 = new File("d:/uploads/" + userId + "-" + fileUploadDTO.getLetterOfAgreement().getOriginalFilename()); 
		File targetDir5 = new File("d:/uploads/" + userId + "-" +  fileUploadDTO.getNoc().getOriginalFilename()); 
		File targetDir6 = new File("d:/uploads/" + userId + "-" + fileUploadDTO.getAgreement().getOriginalFilename()); 
		
		try {
			fileUploadDTO.getAadharCard().transferTo(targetDir1);
			fileUploadDTO.getVoterId().transferTo(targetDir2);
			fileUploadDTO.getSalarySlip().transferTo(targetDir3);
			fileUploadDTO.getLetterOfAgreement().transferTo(targetDir4);
			fileUploadDTO.getNoc().transferTo(targetDir5);
			fileUploadDTO.getAgreement().transferTo(targetDir6);
			
		}
		catch (IOException e) {
			e.printStackTrace(); //if copy fails, throw an exception instead
		}
		
		
		userService.fileUpload(fileUploadDTO, user);
		
		model.put("FileUpload", fileUploadDTO);
		
		return "/confirmationUpload.jsp";
	}
	
	

	
/*	@RequestMapping(path="/fetch", method=RequestMethod.GET)
	public String list(@RequestParam int id, Map<String, Object> model, HttpServletRequest request) {
		FileUploadEntity fileUploadEntity = userService.getRegisteredUser(id);
		
		String appRoot = request.getServletContext().getRealPath("/");
		File srcFile = new File("d:/uploads/" + fileUploadEntity.getProfilePicFileName());
		File destFile = new File(appRoot + "/uploads/"+fileUploadEntity.getProfilePicFileName());
		System.out.println(appRoot);
		System.out.println(srcFile.getName());
		System.out.println(destFile.getName());
		
		try {
			FileUtils.copyFile(srcFile,destFile);
		}
		catch (IOException e) {
			e.printStackTrace(); //if copy fails, throw an exception instead
		}
		
		model.put("user", fileUploadEntity);
		return "/fileFetch.jsp";
	}*/
}
