
	$(document).ready(function() {
		$("#LoginForm").validate({

			rules : {
				emailId : {
					required : true,
					email : true
				},
				password : {
					required : true
				}
			},
			messages : {
				emailId : "Please enter a valid email address",
				password : "Please provide a password"

			}
		});
		$('#SubmitForm').click(function() {

			$("#LoginForm").valid();

		});
	});
